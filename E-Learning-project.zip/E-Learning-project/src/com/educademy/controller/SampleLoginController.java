package com.educademy.controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.educademy.controller.services.SampleLoginRegister;
import com.educademy.model.bean.AddressLoginBean;
import com.educademy.model.bean.SampleLoginBean;

@WebServlet("/SampleLoginController")
public class SampleLoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{

		String name=request.getParameter("name");
		int age=Integer.parseInt(request.getParameter("age"));
		String gender=request.getParameter("gender");
		String contact_Number=request.getParameter("num");
		String address=request.getParameter("add");
		String address2=request.getParameter("addl2");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String country=request.getParameter("country");
		String pincode=request.getParameter("pincode");
		String pass=request.getParameter("pass");
		int role=Integer.parseInt(request.getParameter("role"));
		
		SampleLoginRegister sr=new SampleLoginRegister();
		String user_ID=sr.generateId();
		RequestDispatcher rd=null;
		AddressLoginBean ab=new AddressLoginBean(address,address2,city,state,country,pincode);
		HttpSession session = request.getSession();
			try {
				sr.authenticateAddress(ab);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		
		int add=sr.getAddressID(ab);
		SampleLoginBean sb=new SampleLoginBean(user_ID, name, age, gender, contact_Number, add, pass, role);
		
		//PrintWriter out = response.getWriter();
		try {
			
			String output =sr.authenticateService(sb);
			if (output.equals("success")) 
			{
				//response.setContentType("text/html");
				//out.print("Registration Successful!!");
				session.setAttribute("user_ID", user_ID);
				
				rd = request.getRequestDispatcher("/log.jsp");
				rd.forward(request, response);
			} 
			else 
			{
				//out.print("Registration Unsuccessful!!");
				rd = request.getRequestDispatcher("/samplelogin.html");
				rd.forward(request, response);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
