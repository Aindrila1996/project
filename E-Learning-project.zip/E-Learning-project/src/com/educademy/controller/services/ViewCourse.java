package com.educademy.controller.services;

import java.util.ArrayList;
import java.util.List;

import com.educademy.model.bean.CourseBean;
import com.educademy.model.dao.CourseDao;



public class ViewCourse {
	public ArrayList getDetails()throws Exception
	{
		CourseDao d=new CourseDao();
		List<CourseBean> course=new ArrayList<>();
		course=d.select1();
		return (ArrayList) course;
	}
	public ArrayList getDetails1(String a)throws Exception
	{
		CourseDao d=new CourseDao();
		List<CourseBean> course=new ArrayList<>();
		course=d.select1(a);
		return (ArrayList) course;
	}
	
}
