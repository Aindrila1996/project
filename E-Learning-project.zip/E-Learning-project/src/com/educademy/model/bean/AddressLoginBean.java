package com.educademy.model.bean;

public class AddressLoginBean {
	
	private String address;
	private String address2;
	private String city;
	private String state;
	private String country;
	private String pincode;
	
	public AddressLoginBean(String address, String address2, String city, String state, String country,
			String pincode) {
		super();
		this.address = address;
		this.address2 = address2;
		this.city = city;
		this.state = state;
		this.country = country;
		this.pincode = pincode;
	}

	public String getAddress() {
		return address;
	}

	public String getAddress2() {
		return address2;
	}

	public String getCity() {
		return city;
	}

	public String getState() {
		return state;
	}

	public String getCountry() {
		return country;
	}

	public String getPincode() {
		return pincode;
	}
	
	
}
