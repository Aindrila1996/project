package com.educademy.controller.services;

import java.nio.charset.Charset;
import java.sql.Connection;
import java.util.Random;

import com.educademy.model.bean.AddressLoginBean;
import com.educademy.model.bean.SampleLoginBean;
import com.educademy.model.dao.AddressLoginDao;
import com.educademy.model.dao.SampleLoginDao;
import com.educademy.model.dao.util.DBConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



public class SampleLoginRegister {

	public int authenticateAddress(AddressLoginBean address)throws Exception
	{
		int add=0;
		AddressLoginDao add1=new AddressLoginDao();
		add = add1.insert(address);
	
		return add;
	}
	public String authenticateService(SampleLoginBean admin)throws Exception
	{
			
		SampleLoginDao daoimpl=new SampleLoginDao();
		int i=daoimpl.insert(admin);
		if(i==1)
			return "success";
		else
			return "fail";
		
	}
	public String generateId()
	{
		
		 // length is bounded by 256 Character 
        byte[] array = new byte[256]; 
        new Random().nextBytes(array); 
        int n=10;
  
        String randomString = new String(array, Charset.forName("UTF-8")); 
  
        // Create a StringBuffer to store the result 
        StringBuffer id = new StringBuffer(); 
  
        // remove all special char 
        String  AlphaString = randomString .replaceAll("[^A-Za-z]", ""); 
  
        // Append first 20 alphanumeric characters 
        // from the generated random String into the result 
        for (int k = 0; k < AlphaString.length(); k++) { 
  
            if (Character.isLetter(AlphaString.charAt(k)) && (n > 0) || Character.isDigit(AlphaString.charAt(k)) && (n > 0)) 
            { 
  
                id.append(AlphaString.charAt(k)); 
                n--; 
            } 
        } 
  
        // return the resultant string 
        return id.toString(); 
	}
	public int getAddressID(AddressLoginBean alb)
	{
		int id=0;
		Connection conn=DBConnection.getConnect();
		try {
			PreparedStatement ps= conn.prepareStatement("select address_ID from address where Address_Line1=?");
			ps.setString(1, alb.getAddress());
			ResultSet rs= ps.executeQuery();
			while(rs.next()){
				id = rs.getInt("address_ID");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return id;
	}
}