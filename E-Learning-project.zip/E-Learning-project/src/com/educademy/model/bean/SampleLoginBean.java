package com.educademy.model.bean;

public class SampleLoginBean {
	private String user_ID;
	private String Name;
	private int Age;
	private String Gender;
	private String Contact_Number;
	private int Address;
	private String Password;
	private int Role;
	
	
	
	public SampleLoginBean(String user_ID, String name, int Age, String gender, String contact_Number,
			int Address, String password, int Role)
	{
		super();
		this.user_ID = user_ID;
		this.Name = name;
		this.Age = Age;
		this.Gender = gender;
		this.Contact_Number = contact_Number;
		this.Address = Address;
		this.Password = password;
		this.Role = Role;
	}



	public String getUser_ID() {
		return user_ID;
	}

    public String getName() {
		return Name;
	}

	public int getAge() {
		return Age;
	}

    public String getGender() {
		return Gender;
	}


	public String getContact_Number() {
		return Contact_Number;
	}


	public int getAddress() {
		return Address;
	}

	public String getPassword() {
		return Password;
	}


	public int getRole() {
		return Role;
	}

	
}
