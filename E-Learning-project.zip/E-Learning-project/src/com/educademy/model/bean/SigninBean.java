package com.educademy.model.bean;

public class SigninBean 
{
	private String uname;
	private String password;
	
	public SigninBean(String uname, String password) {
		super();
		this.uname = uname;
		this.password = password;
	}

	public String getUname() {
		return uname;
	}

	public String getPassword() {
		return password;
	}
}
