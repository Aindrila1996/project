package com.educademy.model.dao;

import java.sql.Connection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.educademy.model.dao.util.DBConnection;



public class Fetchnamedao {

	public ResultSet select(String email) throws SQLException
	{
		Connection conn=DBConnection.getConnect();
		ResultSet rs=null;
		
			
			Statement st=conn.createStatement();
			String query="select name from user where user_ID='"+email+"'";
			System.out.println(query);
			rs=st.executeQuery(query);
			
						
			return rs;
		}
		
		
	
	public int update(String query)throws Exception
	{
		return 0;
	}
	
	public int delete(String query)throws Exception
	{
		return 0;
	}
	public int insert(String query)throws Exception
	{
		 
		return 0;
	}
}
