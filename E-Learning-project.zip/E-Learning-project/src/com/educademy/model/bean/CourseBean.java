package com.educademy.model.bean;

public class CourseBean {
  private int course_ID;
  private String name;
  private String course_code;
  private String course_desc;
  private String price;
  private String month;
  private String duration;
public CourseBean(int course_ID, String name, String course_code, String course_desc, String price, String month,
		String duration) {
	super();
	this.course_ID = course_ID;
	this.name = name;
	this.course_code = course_code;
	this.course_desc = course_desc;
	this.price = price;
	this.month = month;
	this.duration = duration;
}
public int getCourse_ID() {
	return course_ID;
}
public void setCourse_ID(int course_ID) {
	this.course_ID = course_ID;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getCourse_code() {
	return course_code;
}
public void setCourse_code(String course_code) {
	this.course_code = course_code;
}
public String getCourse_desc() {
	return course_desc;
}
public void setCourse_desc(String course_desc) {
	this.course_desc = course_desc;
}
public String getPrice() {
	return price;
}
public void setPrice(String price) {
	this.price = price;
}
public String getMonth() {
	return month;
}
public void setMonth(String month) {
	this.month = month;
}
public String getDuration() {
	return duration;
}
public void setDuration(String duration) {
	this.duration = duration;
}
  
  
  
  

  
}
