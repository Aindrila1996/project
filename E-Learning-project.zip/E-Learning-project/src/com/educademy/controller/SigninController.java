package com.educademy.controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.educademy.controller.services.Fetchname;
import com.educademy.controller.services.SigninRegister;
import com.educademy.model.bean.SigninBean;

/**
 * Servlet implementation class SigninController
 */
@WebServlet("/SigninController")
public class SigninController extends HttpServlet
{
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		String email=request.getParameter("email");
		String pass=request.getParameter("pass");
		HttpSession session = request.getSession();
		RequestDispatcher rd=null;
		SigninBean sd=new SigninBean(email, pass);
		SigninRegister sr=new SigninRegister();
		String[] aut=sr.authenticateService(sd);
		
			
		
		int i=sr.authenticateUser(aut, email, pass);
		
		Object b = null;
		
			Fetchname ob=new Fetchname();
			
				ResultSet a=null;
				
				
					try {
						a = ob.fetchname(email);
					
					if(a.next())
					{
						b=a.getString("name");
					}
				
					}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(i==1)
		{
			session.setAttribute("name1", b);
			session.setAttribute("user_ID", email);
			rd=request.getRequestDispatcher("AdminHome.jsp");
			rd.forward(request, response);
		}
		else if(i==2)
		{   
			session.setAttribute("name1", b);
			session.setAttribute("user_ID", email);
			rd=request.getRequestDispatcher("vendor.jsp");
			rd.forward(request, response);
		}
		else if(i==0)
		{
			
			session.setAttribute("name1", b);
			session.setAttribute("user_ID", email);
			rd=request.getRequestDispatcher("user.jsp");
			rd.forward(request, response);
		}
		else
		{
			rd=request.getRequestDispatcher("signin.html");
			rd.forward(request, response);
		}
	
		}
	}

	
