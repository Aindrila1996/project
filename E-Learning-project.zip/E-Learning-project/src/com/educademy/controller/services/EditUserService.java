package com.educademy.controller.services;


import com.educademy.model.bean.UpdateBean;
import com.educademy.model.dao.UpdateDAO;

public class EditUserService {

	public String updateService(UpdateBean b) throws Exception {
		UpdateDAO daoimpl=new UpdateDAO();
		int i=daoimpl.update(b);
		if(i==1)
			return "updated";
		else
			return "not updated";
	
		
	}

}
