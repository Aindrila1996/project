package com.educademy.controller.services;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.educademy.model.bean.SigninBean;
import com.educademy.model.dao.SigninDao;

public class SigninRegister 
{
	public String[] authenticateService(SigninBean sb)
	{
		String[] message=new String[3];
		SigninDao sd=new SigninDao();
		
		ResultSet rs=sd.insert(sb);
		try {
			if (rs.next())
			{
				message[0]=rs.getString(1);
				message[1]=rs.getString(2);
				message[2]=Integer.toString(rs.getInt(3));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return message;
	}
	
	public int authenticateUser(String[] str, String email, String pass)
	{
		int i=-1;
		int j= Integer.parseInt(str[2]);
		if(str[0].equals(email))
		{
			if(str[1].equals(pass))
			{
				if(j==1)
				{
					i=1;
				}
				else if(j==2)
				{
					i=2;
				}
				else if(j==0)
				{
					i=0;
				}
			}
			else
			{
				i=-1;
			}
		}
		else
		{
			i=-1;
		}
		System.out.println(i);
		return i;
	}
}
